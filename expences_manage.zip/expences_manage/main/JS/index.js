document.addEventListener('DOMContentLoaded', function () {
    const expenseForm = document.getElementById('expenseForm');
    const expenseList = document.getElementById('expenseList');

    expenseForm.addEventListener('submit', function (event) {
        event.preventDefault();

        const description = expenseForm.querySelector('#description').value;
        const amount = parseFloat(expenseForm.querySelector('#amount').value);

        if (!description || isNaN(amount)) {
            alert('Please enter valid description and amount.');
            return;
        }

        addExpense(description, amount);
        expenseForm.reset();
    });

    function addExpense(description, amount) {
        const listItem = document.createElement('li');
        listItem.textContent = `${description}: ${amount.toFixed(2)} Polish Zloty`;

        expenseList.appendChild(listItem);
    }
});
