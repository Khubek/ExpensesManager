const express = require('express');
const path = require('path');
const mysql = require('mysql');

const app = express();
const PORT = process.env.PORT || 3000;

// Ustawienie middleware dla parsera danych JSON
app.use(express.json());

// Połączenie z bazą danych MySQL
const connection = mysql.createConnection({
    host: 'localhost',
    user: 'root', // Twój użytkownik MySQL
    password: '', // Twoje hasło MySQL
    database: 'expenses_manager'
});

// Obsługa błędów połączenia z bazą danych
connection.connect((err) => {
    if (err) {
        console.error('Error connecting to MySQL database: ' + err.stack);
        return;
    }
    console.log('Connected to MySQL database as id ' + connection.threadId);
});

// Obsługa żądań POST do dodawania nowego wydatku
app.post('/addExpense', (req, res) => {
    const { description, amount } = req.body;

    if (!description || isNaN(amount)) {
        return res.status(400).json({ error: 'Invalid description or amount' });
    }

    // Dodawanie nowego wydatku do bazy danych
    const sql = 'INSERT INTO expenses (description, amount) VALUES (?, ?)';
    connection.query(sql, [description, amount], (error, results, fields) => {
        if (error) {
            console.error('Error adding expense: ' + error);
            return res.status(500).json({ error: 'Error adding expense' });
        }
        console.log('Expense added successfully');
        res.status(201).json({ message: 'Expense added successfully' });
    });
});

// Serwowanie statycznych plików HTML, CSS i JS
app.use(express.static(path.join(__dirname)));

// Nasłuchiwanie na określonym porcie
app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
});
